import image from "./image.jpeg";

const LakshyarithmContent = [
  {
    title: "lorem",
    image: image,
    content: "Lorem, ipsum dolor sit amet consectetur",
  },
  {
    title: "lorem",
    image: image,
    content: "Lorem, ipsum dolor sit amet consectetur",
  },
  {
    title: "lorem",
    image: image,
    content: "Lorem, ipsum dolor sit amet consectetur",
  },
  {
    title: "lorem",
    image: image,
    content: "Lorem, ipsum dolor sit amet consectetur",
  },
];

export default LakshyarithmContent;
