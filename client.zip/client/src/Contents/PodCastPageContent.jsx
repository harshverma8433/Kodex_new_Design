const video = [
  {
    videourl: "https://www.youtube.com/embed/Vsx9a7-IXX4?si=YaJ09LnZbVCIt6zU",
    content:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, facilis ipsam? Corrupti architecto aspernatur iure unde reprehenderit laborum impedit, quam quae ipsam? Odit nemo, eum eligendi voluptates nam enim fugit!",
  },
  {
    videourl: "https://www.youtube.com/embed/Vsx9a7-IXX4?si=YaJ09LnZbVCIt6zU",
    content:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, facilis ipsam? Corrupti architecto aspernatur iure unde reprehenderit laborum impedit, quam quae ipsam? Odit nemo, eum eligendi voluptates nam enim fugit!",
  },
];

export default video;
