import image from "./image.jpeg";
const AlgoAcharyaSliderContent = [
  {
    image: image,
    content:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis alias, soluta nostrum assumenda nobis excepturi cupiditate fugit ipsa officiis nam perferendis culpa libero, ipsum quos maiores at ratione, modi quidem.",
  },
  {
    image: image,
    content:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis alias, soluta nostrum assumenda nobis excepturi cupiditate fugit ipsa officiis nam perferendis culpa libero, ipsum quos maiores at ratione, modi quidem.",
  },
];

export default AlgoAcharyaSliderContent;