import image from "./image.jpeg";

const AlgoAcharyaContent = [
  {
    title: "lorem",
    image: image,
    content: "Lorem, ipsum dolor sit amet consectetur",
  },
  {
    title: "lorem",
    image: image,
    content: "Lorem, ipsum dolor sit amet consectetur",
  },
  {
    title: "lorem",
    image: image,
    content: "Lorem, ipsum dolor sit amet consectetur",
  },
  {
    title: "lorem",
    image: image,
    content: "Lorem, ipsum dolor sit amet consectetur",
  },
];

export default AlgoAcharyaContent;
