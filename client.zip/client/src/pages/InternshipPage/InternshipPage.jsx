import React from 'react'

const InternshipPage = () => {
  return (
    <div>InternshipPage</div>
  )
}

export default InternshipPage