import React from 'react'

const CoursePage = () => {
  return (
    <div>CoursePage</div>
  )
}

export default CoursePage