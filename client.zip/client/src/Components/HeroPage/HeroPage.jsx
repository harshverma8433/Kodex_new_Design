import "./HeroPage.css";
import heroimage from "./hero_image.png"
function HeroPage() {
  return (
    <div className=" h-[550px] mb-36 mt-10">
      <div>
      <div className="relative flex flex-col lg:flex-row  mb-8">
        <div className="md:flex md:flex-row lg:w-full flex flex-col-reverse">
          

          <div className="flex relative ">
            <img src={heroimage} alt="" />
            <div className=" lg:mb-0  absolute">
                <div className="px-3 pt-6 flex items-center mt-36 ml-24">
                  <h1 className="  text-white  lg:text-4xl font-bold  leading-relaxed">
                    Your Gateway to <br /> Innovation and <br /> Success
                    Revolutionizing <br />
                    Learning and Software <br /> Solutions
                  </h1>

                  
                </div>

                {/* <div className="flex flex-col mt-8 md:flex-row gap-4 lg:gap-8">
                  <button className="bg-indigo-950 text-white font-bold  flex justify-center items-center py-3 md:w-[20%] px-8 lg:py-2 lg:px-14 rounded-full text-base lg:text-xl">
                    TRAININGS
                  </button>
                  <button
                    id="gradient-color"
                    className="bg-black border border-gray-900 flex justify-center items-center text-white font-bold md:w-[20%] py-2 px-8 lg:py-2 lg:px-14  rounded-full text-base lg:text-xl"
                  >
                    SERVICES
                  </button>
                </div> */}
              </div>
          </div>
          
        </div>
        
      </div>

      <div className="row mt-28 w-[90%] mx-auto  justify-content-center">
            <div className="col-12">
              <div className="horizontal-band mx-auto"></div>
            </div>
          </div>


      
    </div>
       {/* <div className="bg-grad-homepage relative left-[1200px]   bottom-[90%] "></div> */}
       
       
       </div>
  );
}

export default HeroPage;
