import Institute from "./Institute";

const OurTeam = () =>{
    return(

        <div className="">
            <h1 className="text-white text-center text-4xl  tracking-wide text-font py-16">OUR TEAM</h1>
        <div className="flex justify-center mb-16  space-x-16">

            <Institute />
            <Institute />
            <Institute />
        </div>

        </div>

    )
}

export default OurTeam;