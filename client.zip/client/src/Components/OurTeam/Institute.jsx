import "./Institute.css"
const Institute = () => {
    return(
        <div className="w-[17%] h-80 rounded-xl bgcol3">
        </div>
    )
}

export default Institute;