import React from 'react'

const Boxes = () => {
  return (
    <div className='w-48 h-10 rounded-3xl bg-box-col'>
        
    </div>
  )
}

export default Boxes